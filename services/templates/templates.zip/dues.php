<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>DakshinPay</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
}
.style1 {font-size: 12px}
.style3 {color: #FFFFFF}
.style4 {
	font-size: 50px;
	font-weight: bold;
}
.style7 {font-size: 36px}
.style8 {color: #FFFFFF; font-size: 18px; }
.style9 {font-size: 14px}
-->
</style></head>

<body>
<table width="600" height="599" border="0" align="center" cellpadding="0" cellspacing="0" style="background: url('profile-bg.jpg'); background-size: cover; background-position:bottom;">
  <tr>
    <td height="108" align="center" bgcolor="#FFFFFF" style="border: 2px solid #4495ff;"><img src="dakshinpay logo_small.png" width="130" height="128" /></td>
  </tr>
  <tr>
    <td height="324" align="center"><p>&nbsp;</p>
      <p><img src="bill.png" width="175" height="175" /></p>
      <h2 class="style3">Your Dakshinpay Dues </h2>
      <p class="style3">16th May to 31st May</p>
      <p class="style3 style4" style="margin: 0;"><span class="style7">&#8377;</span>285.0*</p>
      <p class="style8">Due date 3rd June, 2021</p>
      <p class="style3"><a href="" style="border-radius: 100px; padding:10px; width:150px; background:white; border: 0; font-weight:bold; color: #3babff; font-size: 20px;">PAY NOW</a></p>
      <p class="style3">&nbsp;</p></td>
  </tr>
  <tr>
    <td height="123" align="center"><p class="style1"><img src="logo_icon2.png" width="254" height="257" style="opacity: .3; position:absolute; bottom: -250px; margin-left: -287px;" /></p>
      <p class="style3 style9">Remember to clear your dues before the due date to avoid late payment fees.</p>
      <p class="style3 style9">View your bill details in the Dakshinpay  App.</p>
      <p class="style3 style9">CLICK HERE to view and download your statement.<br />
        If you have any quiry please click on Need Help?<br />
        Download the DakshinPay App       </p>
    <p class="style1">&nbsp;</p></td>
  </tr>
</table>
</body>
</html>
